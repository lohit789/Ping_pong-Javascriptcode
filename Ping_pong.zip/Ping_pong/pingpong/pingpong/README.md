Ping-Pong
---
Here's a ping-pong implemented on HTML Canvas + JavaScript.